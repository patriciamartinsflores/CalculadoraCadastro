package com.compasso.calculadoraDiluicao.service;

import java.net.URI;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.compasso.calculadoraDiluicao.repository.DiluicaoConfiguracaoRepository;
import com.compasso.calculadoraDiluicao.repository.HistoricoRepository;
import com.compasso.calculadoraDiluicao.repository.MedicamentoRepository;
import com.compasso.calculadoraDiluicao.repository.ViaAdministracaoRepository;
import com.compasso.calculadoraDiluicao.modelo.DiluicaoConfiguracaoEntity;
import com.compasso.calculadoraDiluicao.modelo.DiluicaoConfiguracaoId;
import com.compasso.calculadoraDiluicao.modelo.GrupoMedicamentoEntity;
import com.compasso.calculadoraDiluicao.modelo.HistoricoEntity;
import com.compasso.calculadoraDiluicao.modelo.LaboratorioEntity;
import com.compasso.calculadoraDiluicao.modelo.MedicamentoEntity;
import com.compasso.calculadoraDiluicao.modelo.ViaAdministracaoEntity;
import com.compasso.calculadoraDiluicao.dto.HistoricoDto;
import com.compasso.calculadoraDiluicao.dto.LaboratorioDto;
import com.compasso.calculadoraDiluicao.form.CalculoForm;
import com.compasso.calculadoraDiluicao.form.DiluicaoConfiguracaoForm;

@Service
public class CalculoService 
{
	@Autowired
	private DiluicaoConfiguracaoRepository diluicaoConfiguracaoRepository;
	@Autowired
	private HistoricoRepository historicoRepository;
	@Autowired
	private MedicamentoRepository medicamentoRepository;
	@Autowired
	private ViaAdministracaoRepository viaAdministracaoRepository;
	
	String resultadosJson;

	public ResponseEntity<HistoricoDto> calcular(@Valid CalculoForm form, UriComponentsBuilder uriBuilder) 
	{		
		/*DiluicaoConfiguracaoId idReconstituicao = new DiluicaoConfiguracaoId(
				validaMedicamento(form.getIdMedicamento()),
				validaViaAdministracao(form.getIdViaAdministracao()),(long)0);
		DiluicaoConfiguracaoEntity reconstituicao = validaDiluicaoConfiguracao(idReconstituicao);
		resultadosJson = "Passo 1:"+ reconstituicao.getModoPreparo();
		
		resultadosJson = "Passo 2";
		DiluicaoConfiguracaoId idRediluicao = new DiluicaoConfiguracaoId(
				validaMedicamento(form.getIdMedicamento()),
				validaViaAdministracao(form.getIdViaAdministracao()),(long)1);
		DiluicaoConfiguracaoEntity rediluicao = validaDiluicaoConfiguracao(idRediluicao);
		
		//
		 // aqui vai ficar a logica do calculo
		 //
		HistoricoEntity historico = new HistoricoEntity(LocalDateTime.now());
		historicoRepository.save(historico);
		URI uri = uriBuilder.path("/calculo/{id}").buildAndExpand(historico.getId()).toUri();										
		return ResponseEntity.created(uri).body(new HistoricoDto(historico));
	*/return null;
	  }
	 


	public List<HistoricoDto> listaGeral() 
	{
		List<HistoricoEntity>  historicos = historicoRepository.findAll();
		return HistoricoDto.converter(historicos);
	}

	public ResponseEntity<HistoricoDto> listaId(Long id) 
	{
		Optional<HistoricoEntity> optional = historicoRepository.findById(id);
		
		if (optional.isPresent())
		{
			HistoricoEntity historico = optional.get();
			return ResponseEntity.ok(new HistoricoDto(historico));		
		}
		return ResponseEntity.notFound().build();		
	}
	
	private MedicamentoEntity validaMedicamento(Long medicamentoId) throws RuntimeException
	{
		Optional<MedicamentoEntity> medicamentoOptional = medicamentoRepository.findById(medicamentoId);		
		if(medicamentoOptional.isEmpty())
			throw new RuntimeException("Grupo informado nao existe!");
		return medicamentoOptional.get();
	}
		
	private ViaAdministracaoEntity validaViaAdministracao(Long viaAdministracaoId) throws RuntimeException
	{
		Optional<ViaAdministracaoEntity> viaAdministracaoOptional = viaAdministracaoRepository.findById(viaAdministracaoId);		
		if(viaAdministracaoOptional.isEmpty())
			throw new RuntimeException("Via de administração informada nao existe!");
		return viaAdministracaoOptional.get();
	}
	
	private DiluicaoConfiguracaoEntity validaDiluicaoConfiguracao(DiluicaoConfiguracaoId diluicaoConfiguracaoId) throws RuntimeException
	{
		Optional<DiluicaoConfiguracaoEntity> diluicaoConfiguracaoOptional = diluicaoConfiguracaoRepository.findById(diluicaoConfiguracaoId);		
		if(diluicaoConfiguracaoOptional.isEmpty())
			throw new RuntimeException("Não existe modo de preparo para o medicamento e a via de administracao informados!");
		return diluicaoConfiguracaoOptional.get();
	}
}
