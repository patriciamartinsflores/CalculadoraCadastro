package com.compasso.calculadoraDiluicao.service;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.compasso.calculadoraDiluicao.dto.ViaAdministracaoDto;
import com.compasso.calculadoraDiluicao.form.ViaAdministracaoForm;
import com.compasso.calculadoraDiluicao.modelo.ViaAdministracaoEntity;
import com.compasso.calculadoraDiluicao.repository.ViaAdministracaoRepository;

@Service
public class ViaAdministracaoService {
	@Autowired
	private ViaAdministracaoRepository viaAdministracaoRepository;
			
	@Transactional
	public ResponseEntity<ViaAdministracaoDto> cadastrar(ViaAdministracaoForm form, UriComponentsBuilder uriBuilder) throws RuntimeException
	{	
			Optional<ViaAdministracaoEntity> optional = viaAdministracaoRepository.findByNome(form.getNome());
			
			if (optional.isPresent())
				throw new RuntimeException("Impossível cadastrar dois laboratórios com o mesmo nome!");		

			ViaAdministracaoEntity viaAdministracao = new ViaAdministracaoEntity(form.getNome());
			viaAdministracaoRepository.save(viaAdministracao);
			URI uri = uriBuilder.path("/ViaAdministracao/{id}").buildAndExpand(viaAdministracao.getId()).toUri();										
			return ResponseEntity.created(uri).body(new ViaAdministracaoDto(viaAdministracao));
	}
	
	@Transactional //comita no final do metodo
	public ResponseEntity<ViaAdministracaoDto> atualizar(Long id, ViaAdministracaoForm form)
	throws RuntimeException
	{
		Optional<ViaAdministracaoEntity> optional = viaAdministracaoRepository.findById(id);
		
		if (optional.isPresent())
		{
			Optional<ViaAdministracaoEntity> optional2 = viaAdministracaoRepository.findByNome(form.getNome());
			if(optional2.isPresent()) 
			{
				ViaAdministracaoEntity viaAdministracao2 = optional2.get();
				if (viaAdministracao2.getId() != id)
					throw new RuntimeException("Impossível cadastrar dois laboratórios com o mesmo nome!");
				ViaAdministracaoEntity viaAdministracao = optional.get();
				viaAdministracao.setNome(form.getNome());
				return ResponseEntity.ok(new ViaAdministracaoDto(viaAdministracao));							
			}			
		}
		return ResponseEntity.notFound().build();
	}
	
	
	public List<ViaAdministracaoDto> listaGeral() 
	{
		List<ViaAdministracaoEntity> viaAdministracaos = viaAdministracaoRepository.findAll();
		return ViaAdministracaoDto.converter(viaAdministracaos);
	}
	
	public ResponseEntity<ViaAdministracaoDto> listaId(Long id) 
	{
		Optional<ViaAdministracaoEntity> optional = viaAdministracaoRepository.findById(id);
		
		if (optional.isPresent())
		{
			ViaAdministracaoEntity viaAdministracao = optional.get();
			return ResponseEntity.ok(new ViaAdministracaoDto(viaAdministracao));		
		}
		return ResponseEntity.notFound().build();				
	}
	
	public ResponseEntity<ViaAdministracaoDto> listaNome(String nome) 
	{
		Optional<ViaAdministracaoEntity> optional = viaAdministracaoRepository.findByNome(nome);
		
		if (optional.isPresent())
		{
			ViaAdministracaoEntity viaAdministracao = optional.get();
			return ResponseEntity.ok(new ViaAdministracaoDto(viaAdministracao));		
		}
		return ResponseEntity.notFound().build();				
	}
	
	@Transactional //comita no final do metodo
	public ResponseEntity<?> remover(Long id)
	{
		Optional<ViaAdministracaoEntity> optional = viaAdministracaoRepository.findById(id);
		if (optional.isPresent())
		{
			viaAdministracaoRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}
		return ResponseEntity.notFound().build();
	}
	
}
