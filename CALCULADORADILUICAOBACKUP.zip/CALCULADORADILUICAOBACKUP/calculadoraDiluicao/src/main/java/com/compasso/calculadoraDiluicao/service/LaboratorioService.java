package com.compasso.calculadoraDiluicao.service;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.compasso.calculadoraDiluicao.dto.LaboratorioDto;
import com.compasso.calculadoraDiluicao.form.LaboratorioForm;
import com.compasso.calculadoraDiluicao.modelo.LaboratorioEntity;
import com.compasso.calculadoraDiluicao.repository.LaboratorioRepository;
import com.compasso.calculadoraDiluicao.repository.MedicamentoRepository;


@Service
public class LaboratorioService 
{	
	@Autowired
	private LaboratorioRepository laboratorioRepository;
	
	@Autowired
	private MedicamentoRepository medicamentoRepository;
	
		
	@Transactional
	public ResponseEntity<LaboratorioDto> cadastrar(LaboratorioForm form, UriComponentsBuilder uriBuilder) throws RuntimeException
	{	
			Optional<LaboratorioEntity> optional = laboratorioRepository.findByNome(form.getNome());
			
			if (optional.isPresent())
				throw new RuntimeException("Impossível cadastrar dois laboratórios com o mesmo nome!");		

			LaboratorioEntity laboratorio = new LaboratorioEntity(form.getNome());
			laboratorioRepository.save(laboratorio);
			URI uri = uriBuilder.path("/Laboratorio/{id}").buildAndExpand(laboratorio.getId()).toUri();										
			return ResponseEntity.created(uri).body(new LaboratorioDto(laboratorio));
	}
	
	@Transactional //comita no final do metodo
	public ResponseEntity<LaboratorioDto> atualizar(Long id, LaboratorioForm form)
	throws RuntimeException
	{
		Optional<LaboratorioEntity> optional = laboratorioRepository.findById(id);
		
		if (optional.isPresent())
		{
			Optional<LaboratorioEntity> optional2 = laboratorioRepository.findByNome(form.getNome());
			if(optional2.isPresent()) 
			{
				LaboratorioEntity laboratorio2 = optional2.get();
				if (laboratorio2.getId() != id)
					throw new RuntimeException("Impossível cadastrar dois laboratórios com o mesmo nome!");
				LaboratorioEntity laboratorio = optional.get();
				laboratorio.setNome(form.getNome());
				return ResponseEntity.ok(new LaboratorioDto(laboratorio));							
			}			
		}
		return ResponseEntity.notFound().build();
	}
	
	
	public List<LaboratorioDto> listaGeral() 
	{
		List<LaboratorioEntity> laboratorios = laboratorioRepository.findAll();
		return LaboratorioDto.converter(laboratorios);
	}
	
	public ResponseEntity<LaboratorioDto> listaId(Long id) 
	{
		Optional<LaboratorioEntity> optional = laboratorioRepository.findById(id);
		
		if (optional.isPresent())
		{
			LaboratorioEntity laboratorio = optional.get();
			return ResponseEntity.ok(new LaboratorioDto(laboratorio));		
		}
		return ResponseEntity.notFound().build();				
	}
	
	public ResponseEntity<LaboratorioDto> listaNome(String nome) 
	{
		Optional<LaboratorioEntity> optional = laboratorioRepository.findByNome(nome);
		
		if (optional.isPresent())
		{
			LaboratorioEntity laboratorio = optional.get();
			return ResponseEntity.ok(new LaboratorioDto(laboratorio));		
		}
		return ResponseEntity.notFound().build();				
	}
	
	@Transactional //comita no final do metodo
	public ResponseEntity<?> remover(Long id)
	{
		Optional<LaboratorioEntity> optional = laboratorioRepository.findById(id);
		if (optional.isPresent())
		{//o que fazer no delete?
			medicamentoRepository.deleteByLaboratorioId(id);
			laboratorioRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}
		return ResponseEntity.notFound().build();
	}
	

	

}
