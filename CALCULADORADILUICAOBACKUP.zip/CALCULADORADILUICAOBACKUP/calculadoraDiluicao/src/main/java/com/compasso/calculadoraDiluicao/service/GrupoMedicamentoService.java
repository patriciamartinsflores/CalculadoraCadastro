package com.compasso.calculadoraDiluicao.service;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import com.compasso.calculadoraDiluicao.dto.GrupoMedicamentoDto;
import com.compasso.calculadoraDiluicao.form.GrupoMedicamentoForm;
import com.compasso.calculadoraDiluicao.modelo.GrupoMedicamentoEntity;
import com.compasso.calculadoraDiluicao.repository.GrupoMedicamentoRepository;
import com.compasso.calculadoraDiluicao.repository.MedicamentoRepository;

@Service
public class GrupoMedicamentoService {
	
	@Autowired
	private GrupoMedicamentoRepository grupoMedicamentoRepository;
	
	@Autowired
	private MedicamentoRepository medicamentoRepository;
	
		
	@Transactional
	public ResponseEntity<GrupoMedicamentoDto> cadastrar(GrupoMedicamentoForm form, UriComponentsBuilder uriBuilder) throws RuntimeException
	{	
			Optional<GrupoMedicamentoEntity> optional = grupoMedicamentoRepository.findByNome(form.getNome());
			
			if (optional.isPresent())
				throw new RuntimeException("Impossível cadastrar dois laboratórios com o mesmo nome!");		

			GrupoMedicamentoEntity grupoMedicamento = new GrupoMedicamentoEntity(form.getNome());
			grupoMedicamentoRepository.save(grupoMedicamento);
			URI uri = uriBuilder.path("/Laboratorio/{id}").buildAndExpand(grupoMedicamento.getId()).toUri();										
			return ResponseEntity.created(uri).body(new GrupoMedicamentoDto(grupoMedicamento));
	}
	
	@Transactional //comita no final do metodo
	public ResponseEntity<GrupoMedicamentoDto> atualizar(Long id, GrupoMedicamentoForm form)
	throws RuntimeException
	{
		Optional<GrupoMedicamentoEntity> optional = grupoMedicamentoRepository.findById(id);
		
		if (optional.isPresent())
		{
			Optional<GrupoMedicamentoEntity> optional2 = grupoMedicamentoRepository.findByNome(form.getNome());
			if(optional2.isPresent()) 
			{
				GrupoMedicamentoEntity grupoMedicamento2 = optional2.get();
				if (grupoMedicamento2.getId() != id)
					throw new RuntimeException("Impossível cadastrar dois laboratórios com o mesmo nome!");
				GrupoMedicamentoEntity grupoMedicamento = optional.get();
				grupoMedicamento.setNome(form.getNome());
				return ResponseEntity.ok(new GrupoMedicamentoDto(grupoMedicamento));							
			}			
		}
		return ResponseEntity.notFound().build();
	}
	
	
	public List<GrupoMedicamentoDto> listaGeral() 
	{
		List<GrupoMedicamentoEntity> laboratorios = grupoMedicamentoRepository.findAll();
		return GrupoMedicamentoDto.converter(laboratorios);
	}
	
	public ResponseEntity<GrupoMedicamentoDto> listaId(Long id) 
	{
		Optional<GrupoMedicamentoEntity> optional = grupoMedicamentoRepository.findById(id);
		
		if (optional.isPresent())
		{
			GrupoMedicamentoEntity laboratorio = optional.get();
			return ResponseEntity.ok(new GrupoMedicamentoDto(laboratorio));		
		}
		return ResponseEntity.notFound().build();				
	}
	
	public ResponseEntity<GrupoMedicamentoDto> listaNome(String nome) 
	{
		Optional<GrupoMedicamentoEntity> optional = grupoMedicamentoRepository.findByNome(nome);
		
		if (optional.isPresent())
		{
			GrupoMedicamentoEntity grupoMedicamento = optional.get();
			return ResponseEntity.ok(new GrupoMedicamentoDto(grupoMedicamento));		
		}
		return ResponseEntity.notFound().build();				
	}
	
	@Transactional //comita no final do metodo
	public ResponseEntity<?> remover(Long id)
	{
		Optional<GrupoMedicamentoEntity> optional = grupoMedicamentoRepository.findById(id);
		if (optional.isPresent())
		{
			medicamentoRepository.deleteByLaboratorioId(id);
			grupoMedicamentoRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}
		return ResponseEntity.notFound().build();
	}
	
}
