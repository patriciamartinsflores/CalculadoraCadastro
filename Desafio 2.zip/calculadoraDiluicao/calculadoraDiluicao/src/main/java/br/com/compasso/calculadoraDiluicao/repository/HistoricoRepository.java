package br.com.compasso.calculadoraDiluicao.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.compasso.calculadoraDiluicao.modelo.HistoricoEntity;


public interface HistoricoRepository extends JpaRepository<HistoricoEntity, Long>{ 
	public List<HistoricoEntity> findByNomeMedicamentoAndDataCalculoBetween(String nome, LocalDateTime dataInicio, LocalDateTime dataFim);
	
	
}