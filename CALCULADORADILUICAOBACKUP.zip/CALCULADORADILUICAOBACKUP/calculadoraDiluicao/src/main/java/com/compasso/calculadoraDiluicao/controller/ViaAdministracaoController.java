package com.compasso.calculadoraDiluicao.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.compasso.calculadoraDiluicao.dto.ViaAdministracaoDto;
import com.compasso.calculadoraDiluicao.form.ViaAdministracaoForm;
import com.compasso.calculadoraDiluicao.service.ViaAdministracaoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value="API Rest cadastro de vias de administracao de medicamentos")
@RestController
public class ViaAdministracaoController 
{
	@Autowired
	private ViaAdministracaoService viaAdministracaoService;
	
	@ApiOperation(value="retorna lista de vias")
	@RequestMapping("/viaAdministracao/listar")
	public List<ViaAdministracaoDto> listaGeral() 
	{
		return viaAdministracaoService.listaGeral();
	}
	
	@ApiOperation(value="retorna via por id")
	@RequestMapping("/viaAdministracao/listar/{id}")
	public ResponseEntity<ViaAdministracaoDto> listaId(@PathVariable Long id) 
	{
		return viaAdministracaoService.listaId(id);
	}

	@ApiOperation(value="retorna via por nome")
	@RequestMapping("/viaAdministracao/listar/{nome}")
	public ResponseEntity<ViaAdministracaoDto> listaNome(@PathVariable String nome) 
	{
		return viaAdministracaoService.listaNome(nome);
	}



	@ApiOperation(value="cadastra uma via no banco de dados")
	@RequestMapping("/viaAdministracao/criar")
	public ResponseEntity<ViaAdministracaoDto> cadastrar(@RequestBody @Valid ViaAdministracaoForm form, UriComponentsBuilder uriBuilder) 
	{		
		return viaAdministracaoService.cadastrar(form, uriBuilder);		
	}

	@ApiOperation(value="edita uma via no banco de dados")
	@RequestMapping("/viaAdministracao/atualizar/{id}")
	public ResponseEntity<ViaAdministracaoDto> atualizar(@PathVariable Long id, @RequestBody @Valid ViaAdministracaoForm form)
	{
		return viaAdministracaoService.atualizar(id, form);
	}

	@ApiOperation(value="exclui uma via do banco de dados")
	@RequestMapping("/viaAdministracao/remover/{id}")
	public ResponseEntity<?> remover(@PathVariable Long id)
	{
		return viaAdministracaoService.remover(id);
	}

}