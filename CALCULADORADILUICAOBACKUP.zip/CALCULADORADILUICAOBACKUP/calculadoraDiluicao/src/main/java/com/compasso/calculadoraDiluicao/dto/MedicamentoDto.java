package com.compasso.calculadoraDiluicao.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.compasso.calculadoraDiluicao.modelo.MedicamentoEntity;
import com.compasso.calculadoraDiluicao.repository.DiluicaoConfiguracaoRepository;
import com.compasso.calculadoraDiluicao.service.MedicamentoService;

public class MedicamentoDto 
{
	@Autowired MedicamentoService medicamentoService;
	private Long id;
	private String nome;
	private BigDecimal concentracaoInicial;
	private String embalagemApresentada;
	private Long idGrupoMedicamento;
	private Long idLaboratorio;
	private String infoObservacao;
	private String infoSobra;
	private String infoTempoAdministracao;
	private Long quantidadeApresentacao;
	private String unidadeMedida;
	private List<DiluicaoConfiguracaoDto> diluicoes;
	
	public MedicamentoDto(MedicamentoEntity medicamento) 
	{
		this.id                     = medicamento.getId();
		this.nome                   = medicamento.getNome();
		this.concentracaoInicial    = medicamento.getConcentracaoInicial();
		this.embalagemApresentada   = medicamento.getEmbalagemApresentada();
		this.idGrupoMedicamento     = medicamento.getGrupoMedicamento().getId();
		this.idLaboratorio          = medicamento.getLaboratorio().getId();
		this.infoObservacao         = medicamento.getInfoObservacao();
		this.infoSobra              = medicamento.getInfoSobra();
		this.infoTempoAdministracao = medicamento.getInfoTempoAdministracao();
		this.quantidadeApresentacao = medicamento.getQuantidadeApresentacao();
		this.unidadeMedida          = medicamento.getUnidadeMedida();		
		this.diluicoes              = medicamentoService.getDiluicoes(this.id);
	}

	public void adicionaDiluicaoConfiguracao(DiluicaoConfiguracaoDto diluicao) 
	{
		this.diluicoes.add(diluicao);
	}

	//mover conversao para a service?
	public static List<MedicamentoDto> converter(List<MedicamentoEntity> medicamentos) 
	{
		return medicamentos.stream().map(MedicamentoDto::new).collect(Collectors.toList());
	}

}

