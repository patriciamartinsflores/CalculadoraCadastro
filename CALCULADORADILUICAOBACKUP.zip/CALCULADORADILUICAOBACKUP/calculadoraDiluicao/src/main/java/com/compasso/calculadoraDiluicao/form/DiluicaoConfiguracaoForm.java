package com.compasso.calculadoraDiluicao.form;

import java.math.BigDecimal;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.PositiveOrZero;

import org.hibernate.validator.constraints.Length;

public class DiluicaoConfiguracaoForm 
{	
	@NotBlank @Max(99999999)
	private Long idViaAdministracao;
	
	@NotBlank @Max(2)
	private Long sequencia;
		
	@NotBlank @Length(max=255)
	private String modoPreparo;
	
	@NotBlank @PositiveOrZero @Max(99999999)
	private BigDecimal quantidadeAspirada;
	
	@NotBlank @PositiveOrZero @Max(99999999)
	private BigDecimal quantidadeAdicionada;
	
	@NotBlank @PositiveOrZero @Max(99999999)
	private BigDecimal concentracao;
	
	@NotBlank @Length(max=255)
	private String diluente;

	public DiluicaoConfiguracaoForm(@NotBlank Long idViaAdministracao, @NotBlank Long sequencia,
			@NotBlank String modoPreparo, @NotBlank @PositiveOrZero BigDecimal quantidadeAspirada,
			@NotBlank @PositiveOrZero BigDecimal quantidadeAdicionada,
			@NotBlank @PositiveOrZero BigDecimal concentracao, @NotBlank String diluente) {
		super();
		this.idViaAdministracao   = idViaAdministracao;
		this.sequencia            = sequencia;
		this.modoPreparo          = modoPreparo;
		this.quantidadeAspirada   = quantidadeAspirada;
		this.quantidadeAdicionada = quantidadeAdicionada;
		this.concentracao         = concentracao;
		this.diluente             = diluente;
	}


	public Long getIdViaAdministracao() {
		return idViaAdministracao;
	}


	public void setIdViaAdministracao(Long idViaAdministracao) {
		this.idViaAdministracao = idViaAdministracao;
	}


	public Long getSequencia() {
		return sequencia;
	}


	public void setSequencia(Long sequencia) {
		this.sequencia = sequencia;
	}


	public String getModoPreparo() {
		return modoPreparo;
	}


	public void setModoPreparo(String modoPreparo) {
		this.modoPreparo = modoPreparo;
	}


	public BigDecimal getQuantidadeAspirada() {
		return quantidadeAspirada;
	}


	public void setQuantidadeAspirada(BigDecimal quantidadeAspirada) {
		this.quantidadeAspirada = quantidadeAspirada;
	}


	public BigDecimal getQuantidadeAdicionada() {
		return quantidadeAdicionada;
	}


	public void setQuantidadeAdicionada(BigDecimal quantidadeAdicionada) {
		this.quantidadeAdicionada = quantidadeAdicionada;
	}


	public BigDecimal getConcentracao() {
		return concentracao;
	}


	public void setConcentracao(BigDecimal concentracao) {
		this.concentracao = concentracao;
	}


	public String getDiluente() {
		return diluente;
	}


	public void setDiluente(String diluente) {
		this.diluente = diluente;
	}
		
}
