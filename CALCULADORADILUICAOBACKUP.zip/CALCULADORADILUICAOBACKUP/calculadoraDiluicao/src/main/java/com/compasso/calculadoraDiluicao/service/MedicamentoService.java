package com.compasso.calculadoraDiluicao.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.math.BigDecimal;
import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import com.compasso.calculadoraDiluicao.dto.DiluicaoConfiguracaoDto;
import com.compasso.calculadoraDiluicao.dto.LaboratorioDto;
import com.compasso.calculadoraDiluicao.dto.MedicamentoDto;
import com.compasso.calculadoraDiluicao.form.MedicamentoForm;
import com.compasso.calculadoraDiluicao.form.DiluicaoConfiguracaoForm;
import com.compasso.calculadoraDiluicao.modelo.DiluicaoConfiguracaoEntity;
import com.compasso.calculadoraDiluicao.modelo.DiluicaoConfiguracaoId;
import com.compasso.calculadoraDiluicao.modelo.GrupoMedicamentoEntity;
import com.compasso.calculadoraDiluicao.modelo.LaboratorioEntity;
import com.compasso.calculadoraDiluicao.modelo.MedicamentoEntity;
import com.compasso.calculadoraDiluicao.modelo.ViaAdministracaoEntity;
import com.compasso.calculadoraDiluicao.repository.DiluicaoConfiguracaoRepository;
import com.compasso.calculadoraDiluicao.repository.GrupoMedicamentoRepository;
import com.compasso.calculadoraDiluicao.repository.LaboratorioRepository;
import com.compasso.calculadoraDiluicao.repository.MedicamentoRepository;
import com.compasso.calculadoraDiluicao.repository.ViaAdministracaoRepository;


@Service
public class MedicamentoService {
	
	@Autowired 
	private DiluicaoConfiguracaoRepository diluicaoConfiguracaoRepository;

	@Autowired
	private MedicamentoRepository medicamentoRepository;
	
	@Autowired
	private ViaAdministracaoRepository viaAdministracaoRepository;
		
	@Autowired
	private LaboratorioRepository laboratorioRepository;
	
	@Autowired
	private GrupoMedicamentoRepository grupoMedicamentoRepository;
	
	
	public List<MedicamentoDto> listaGeral() 
	{
		List<MedicamentoEntity> medicamentos = medicamentoRepository.findAll();
		return MedicamentoDto.converter(medicamentos);
	}
	
	public ResponseEntity<MedicamentoDto> listaId(Long id) 
	{
		Optional<MedicamentoEntity> optional = medicamentoRepository.findById(id);
		
		if (optional.isPresent())
		{
			MedicamentoEntity medicamento = optional.get();
			return ResponseEntity.ok(new MedicamentoDto(medicamento));		
		}
		return ResponseEntity.notFound().build();				
	}
	
	public  List<MedicamentoDto> listaNome(String nome) 
	throws RuntimeException{
		List<MedicamentoEntity> medicamentos = medicamentoRepository.findByNome(nome);
		if(medicamentos.isEmpty())
			throw new RuntimeException("Nome não encontrado!");	
		return MedicamentoDto.converter(medicamentos);		
	}
	
	@Transactional
	public ResponseEntity<?> remover(Long id)
	{
		Optional<MedicamentoEntity> optional = medicamentoRepository.findById(id);
		if (optional.isPresent())
		{
			diluicaoConfiguracaoRepository.deleteByIdMedicamentoId(id);
			medicamentoRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}
		return ResponseEntity.notFound().build();
	}
	
	@Transactional
	public ResponseEntity<MedicamentoDto> cadastrar(MedicamentoForm form, UriComponentsBuilder uriBuilder) throws RuntimeException
	{			
		Optional<MedicamentoEntity> medicamentoOptional = medicamentoRepository.findByGrupoMedicamentoIdAndLaboratorioIdAndNomeAndEmbalagemApresentadaAndQuantidadeApresentacao(form.getIdLaboratorio(),form.getIdGrupoMedicamento(), form.getNome(),form.getEmbalagemApresentada(),form.getQuantidadeApresentacao());
		
		if(medicamentoOptional.isPresent())
			throw new RuntimeException("Medicamento com esses dados ja foi cadastrado!");					

		MedicamentoEntity medicamento = new MedicamentoEntity(validaGrupoMedicamento(form.getIdGrupoMedicamento()), validaLaboratorio(form.getIdLaboratorio()),
				form.getNome(),form.getQuantidadeApresentacao(), form.getConcentracaoInicial(), form.getInfoSobra(),
				form.getInfoObservacao(), form.getInfoTempoAdministracao(), form.getUnidadeMedida(), form.getEmbalagemApresentada());						
		medicamentoRepository.save(medicamento);
		
		//aqui abaixo fica a rotina de salvar os dados das diluicaoConfiguracao's
		List<DiluicaoConfiguracaoForm> diluicaoForms = form.getDiluicoes();
		if(!(diluicaoForms.isEmpty()))
			for(DiluicaoConfiguracaoForm diluicaoConfiguracaoForm : diluicaoForms)
			{
				DiluicaoConfiguracaoId id = new DiluicaoConfiguracaoId(medicamento, validaViaAdministracao(diluicaoConfiguracaoForm.getIdViaAdministracao()),diluicaoConfiguracaoForm.getSequencia() );
				DiluicaoConfiguracaoEntity diluicaoConfiguracao = new DiluicaoConfiguracaoEntity(diluicaoConfiguracaoForm.getQuantidadeAspirada(), 
						diluicaoConfiguracaoForm.getQuantidadeAdicionada() ,
						diluicaoConfiguracaoForm.getConcentracao(), diluicaoConfiguracaoForm.getDiluente(), diluicaoConfiguracaoForm.getModoPreparo(), id);
				diluicaoConfiguracaoRepository.save(diluicaoConfiguracao);
			}
		URI uri = uriBuilder.path("/medicamento/{id}").buildAndExpand(medicamento.getId()).toUri();										
		return ResponseEntity.created(uri).body(new MedicamentoDto(medicamento));
	}	
	
	@Transactional //comita no final do metodo
	public ResponseEntity<MedicamentoDto> atualizar(Long id, MedicamentoForm form)
	throws RuntimeException
	{
		Optional<MedicamentoEntity> medicamentoOptional = medicamentoRepository.findByGrupoMedicamentoIdAndLaboratorioIdAndNomeAndEmbalagemApresentadaAndQuantidadeApresentacao(form.getIdLaboratorio(),form.getIdGrupoMedicamento(), form.getNome(),form.getEmbalagemApresentada(),form.getQuantidadeApresentacao());		
		
		if (medicamentoOptional.isPresent())
		{	
			MedicamentoEntity medicamento = medicamentoOptional.get();
			
			if (medicamento.getId() != id)
				throw new RuntimeException("Medicamento com esses dados ja foi cadastrado!");

			medicamento.setNome(form.getNome());
			medicamento.setLaboratorio(validaLaboratorio(form.getIdLaboratorio()));
			medicamento.setGrupoMedicamento(validaGrupoMedicamento(form.getIdGrupoMedicamento()));
			medicamento.setConcentracaoInicial(form.getConcentracaoInicial());
			medicamento.setQuantidadeApresentacao(form.getQuantidadeApresentacao());
			medicamento.setInfoSobra(form.getInfoSobra());
			medicamento.setInfoObservacao(form.getInfoObservacao());
			medicamento.setInfoTempoAdministracao(form.getInfoTempoAdministracao());
			medicamento.setUnidadeMedida(form.getUnidadeMedida());
			medicamento.setEmbalagemApresentada(form.getEmbalagemApresentada());			
			
			List<DiluicaoConfiguracaoForm> diluicaoForms = form.getDiluicoes();
			if(!(diluicaoForms.isEmpty()))				
				for(DiluicaoConfiguracaoForm diluicaoConfiguracaoForm : diluicaoForms)
				{
					DiluicaoConfiguracaoId idDiluicao = new DiluicaoConfiguracaoId(medicamento, validaViaAdministracao(diluicaoConfiguracaoForm.getIdViaAdministracao()),diluicaoConfiguracaoForm.getSequencia() );
					DiluicaoConfiguracaoEntity diluicaoConfiguracao = new DiluicaoConfiguracaoEntity(diluicaoConfiguracaoForm.getQuantidadeAspirada(), 
							diluicaoConfiguracaoForm.getQuantidadeAdicionada() ,
							diluicaoConfiguracaoForm.getConcentracao(), diluicaoConfiguracaoForm.getDiluente(), diluicaoConfiguracaoForm.getModoPreparo(), idDiluicao);
					diluicaoConfiguracaoRepository.save(diluicaoConfiguracao);
				}
			return ResponseEntity.ok(new MedicamentoDto(medicamento));
		}
		return ResponseEntity.notFound().build();
	}
	
	private GrupoMedicamentoEntity validaGrupoMedicamento(Long grupoMedicamentoId) throws RuntimeException
	{
		Optional<GrupoMedicamentoEntity> grupoMedicamentoOptional = grupoMedicamentoRepository.findById(grupoMedicamentoId);		
		if(grupoMedicamentoOptional.isEmpty())
			throw new RuntimeException("Grupo informado nao existe!");
		return grupoMedicamentoOptional.get();
	}
	
	private ViaAdministracaoEntity validaViaAdministracao(Long viaAdministracaoId) throws RuntimeException
	{
		Optional<ViaAdministracaoEntity> viaAdministracaoOptional = viaAdministracaoRepository.findById(viaAdministracaoId);		
		if(viaAdministracaoOptional.isEmpty())
			throw new RuntimeException("Via de administração informada nao existe!");
		return viaAdministracaoOptional.get();
	}
	
	private LaboratorioEntity validaLaboratorio(Long laboratorioId) throws RuntimeException
	{
		Optional<LaboratorioEntity> laboratorioOptional = laboratorioRepository.findById(laboratorioId);		
		if(laboratorioOptional.isEmpty())
			throw new RuntimeException("Laboratorio informado nao existe!");
		return laboratorioOptional.get();		
	}
		
	public List<DiluicaoConfiguracaoDto> getDiluicoes(Long MedicamentoId)
	{
		return DiluicaoConfiguracaoDto.converter(diluicaoConfiguracaoRepository.findByIdMedicamentoId(MedicamentoId));
	}
}
