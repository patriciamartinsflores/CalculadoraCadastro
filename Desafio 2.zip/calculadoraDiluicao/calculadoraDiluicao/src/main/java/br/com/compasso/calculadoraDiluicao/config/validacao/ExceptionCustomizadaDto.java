package br.com.compasso.calculadoraDiluicao.config.validacao;

public class ExceptionCustomizadaDto {
	private String erro;

	
	public ExceptionCustomizadaDto(String erro) {
		this.erro = erro;

	}

	public String getErro() {
		return erro;
	}


		
}
